An OSC to OLED bridge for Linux using u8g2 and Bela's OscReceiver and UdpServer classes.
